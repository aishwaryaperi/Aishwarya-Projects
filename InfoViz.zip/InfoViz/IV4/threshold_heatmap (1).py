import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import gridspec
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA as SKPCA


from pyod.models.knn import KNN
from pyod.models.lof import LOF
from pyod.models.abod import ABOD
from pyod.models.copod import COPOD
from pyod.models.iforest import IForest
from pyod.models.feature_bagging import FeatureBagging
from pyod.models.pca import PCA
from pyod.models.mcd import MCD


INPUT_DIR = r"C:\Users\peria\Downloads"
OUTPUT_DIR = os.path.join(INPUT_DIR, "heatmaps")
os.makedirs(OUTPUT_DIR, exist_ok=True)

COLORMAPS = {
    "Obesity": "coolwarm",
    "TripAdvisor": "summer",
    "Seeds": "spring"
}

HEATMAP_STYLE = {
    "Obesity": "grid_density_thresholded",
    "TripAdvisor": "raw_scores_thresholded",
    "Seeds": "binary_thresholded"

}

MODEL_TYPES = {
    "KNN": "Proximity-Based",
    "LOF": "Proximity-Based",
    "ABOD": "Probabilistic",
    "COPOD": "Probabilistic",
    "IForest": "Ensemble",
    "FB": "Ensemble",
    "PCA": "Linear Model",
    "MCD": "Linear Model",
}

def load_cleaned_data():
    return {
        "Obesity": pd.read_csv(os.path.join(INPUT_DIR, "cleaned_obesity_dataset.csv")),
        "TripAdvisor": pd.read_csv(os.path.join(INPUT_DIR, "cleaned_tripadvisor_dataset.csv")),
        "Seeds": pd.read_csv(os.path.join(INPUT_DIR, "cleaned_seeds_dataset.csv")),
    }

def build_models():
    return {
        "KNN": KNN(),
        "LOF": LOF(),
        "ABOD": ABOD(),
        "COPOD": COPOD(),
        "IForest": IForest(),
        "FB": FeatureBagging(),
        "PCA": PCA(),
        "MCD": MCD(),
    }

def compute_heatmap_Z(model, X2D, xx, yy, style):
    mesh_points = np.c_[xx.ravel(), yy.ravel()]
    Z = model.decision_function(mesh_points) if hasattr(model, "decision_function") else model.predict(mesh_points).astype(float)
    Z = Z.reshape(xx.shape)

    if style == "grid_density_thresholded":
        Z_min, Z_max = Z.min(), Z.max()
        Z_norm = (Z - Z_min) / (Z_max - Z_min) if Z_max > Z_min else np.zeros_like(Z)
        threshold = np.percentile(Z_norm, 95)
        return np.where(Z_norm >= threshold, Z_norm, 0)

    elif style == "raw_scores_thresholded":
        threshold = np.percentile(Z, 95)
        return np.where(Z >= threshold, Z, 0)

    elif style == "binary_thresholded":
        Z_min, Z_max = Z.min(), Z.max()
        Z_norm = (Z - Z_min) / (Z_max - Z_min) if Z_max > Z_min else np.zeros_like(Z)
        threshold = np.percentile(Z_norm, 95)
        return np.where(Z_norm >= threshold, 1, 0)

    else:
        return Z


def plot_thresholded_styled_heatmaps(datasets):
    fig = plt.figure(figsize=(20, 10))
    outer_spec = gridspec.GridSpec(nrows=1, ncols=3, wspace=0.6)

    for i, (dataset_name, df) in enumerate(datasets.items()):
        data = df.select_dtypes(include=[np.number]).dropna()
        X_scaled = StandardScaler().fit_transform(data)
        X2D = SKPCA(n_components=2, random_state=42).fit_transform(X_scaled)

        model_dict = build_models()
        cmap_used = COLORMAPS[dataset_name]
        style = HEATMAP_STYLE[dataset_name]

        x_min, x_max = X2D[:, 0].min() - 0.5, X2D[:, 0].max() + 0.5
        y_min, y_max = X2D[:, 1].min() - 0.5, X2D[:, 1].max() + 0.5
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300), np.linspace(y_min, y_max, 300))

        model_order = sorted(model_dict.keys(), key=lambda m: (MODEL_TYPES[m], m))
        grouped_models = [model_order[i:i + 2] for i in range(0, 8, 2)]

        inner_spec = gridspec.GridSpecFromSubplotSpec(
            nrows=4, ncols=3,
            width_ratios=[0.6, 4, 4],
            wspace=0.2, hspace=0.3,
            subplot_spec=outer_spec[i]
        )

        for row_idx, model_pair in enumerate(grouped_models):
            ax_label = fig.add_subplot(inner_spec[row_idx, 0])
            ax_label.axis("off")
            ax_label.text(0.9, 0.5, MODEL_TYPES[model_pair[0]], fontsize=9,
                          fontweight='bold', rotation=90, ha='right', va='center')

            for col_idx, model_name in enumerate(model_pair):
                ax = fig.add_subplot(inner_spec[row_idx, col_idx + 1])
                model = model_dict[model_name]
                try:
                    model.fit(X2D)
                    Z = compute_heatmap_Z(model, X2D, xx, yy, style)
                    ax.pcolormesh(xx, yy, Z, cmap=cmap_used, shading='auto')
                    ax.scatter(X2D[:, 0], X2D[:, 1], c='black', s=6)
                    ax.set_title(model_name, fontsize=8)
                except Exception as e:
                    print(f"Error with {model_name} on {dataset_name}: {e}")
                    ax.axis("off")

                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_xlim(x_min, x_max)
                ax.set_ylim(y_min, y_max)

        
        fig.text(0.14 + i * 0.33, 0.96, dataset_name, ha='center', fontsize=13, fontweight='bold')

        
        colorbar_left = 0.325 + i * 0.33
        cbar_ax = fig.add_axes([colorbar_left, 0.14, 0.012, 0.72])
        dummy = plt.cm.ScalarMappable(cmap=cmap_used)
        cbar = fig.colorbar(dummy, cax=cbar_ax, ticks=[0, 1])
        label_map = {
            "grid_density_thresholded": ["Likely Inlier", "Likely Outlier"],
            "raw_scores_thresholded": ["Likely Inlier", "Likely Outlier"],
            "binary_thresholded": ["Likely Inlier", "Likely Outlier"]
        }
        cbar.ax.set_yticklabels(label_map[style])
        cbar.ax.tick_params(labelsize=8)

    output_path = os.path.join(OUTPUT_DIR, "threshold_heatmap.png")
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"\nFinal saved at: {output_path}")


if __name__ == "__main__":
    datasets = load_cleaned_data()
    plot_thresholded_styled_heatmaps(datasets)
