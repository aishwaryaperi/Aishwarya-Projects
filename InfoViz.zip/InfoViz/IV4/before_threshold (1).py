import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import gridspec
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA as SKPCA
from pyod.models.knn import KNN
from pyod.models.lof import LOF
from pyod.models.abod import ABOD
from pyod.models.copod import COPOD
from pyod.models.iforest import IForest
from pyod.models.feature_bagging import FeatureBagging
from pyod.models.pca import PCA
from pyod.models.mcd import MCD

warnings.filterwarnings("ignore")


INPUT_DIR = r"C:\Users\peria\Downloads"


OUTPUT_DIR = os.path.join(INPUT_DIR, "heatmaps")
os.makedirs(OUTPUT_DIR, exist_ok=True)


COLORMAPS = {
    "Obesity": "coolwarm",
    "TripAdvisor": "summer",
    "Seeds": "spring"
}

HEATMAP_TYPE = {
    "Obesity": "grid_density",     
    "TripAdvisor": "raw_scores",   
    "Seeds": "binary"   
}           


MODEL_TYPES = {
    "KNN": "Proximity-Based",
    "LOF": "Proximity-Based",
    "ABOD": "Probabilistic",
    "COPOD": "Probabilistic",
    "IForest": "Ensemble",
    "FB": "Ensemble",
    "PCA": "Linear Model",
    "MCD": "Linear Model",
}

def load_cleaned_data():
    return {
        "Obesity": pd.read_csv(os.path.join(INPUT_DIR, "cleaned_obesity_dataset.csv")),
        "TripAdvisor": pd.read_csv(os.path.join(INPUT_DIR, "cleaned_tripadvisor_dataset.csv")),
        "Seeds": pd.read_csv(os.path.join(INPUT_DIR, "cleaned_seeds_dataset.csv")),
    }


def build_models():
    return {
        "KNN": KNN(),
        "LOF": LOF(),
        "ABOD": ABOD(),
        "COPOD": COPOD(),
        "IForest": IForest(),
        "FB": FeatureBagging(),
        "PCA": PCA(),
        "MCD": MCD(),
    }


def compute_outlier_scores_2d(model, X2D, grid_x, grid_y, mode):
    mesh_points = np.c_[grid_x.ravel(), grid_y.ravel()]
    if hasattr(model, "decision_function"):
        Z = model.decision_function(mesh_points)
    else:
        Z = model.predict(mesh_points).astype(float)

    Z = Z.reshape(grid_x.shape)

    if mode == "binary":
        threshold = np.percentile(Z, 90)
        Z = (Z >= threshold).astype(float)
    elif mode == "raw_scores":
        Z = Z
    elif mode == "grid_density":
        Z_min, Z_max = Z.min(), Z.max()
        Z = (Z - Z_min) / (Z_max - Z_min) if Z_max - Z_min >= 1e-12 else np.zeros_like(Z)

    return Z


def plot_side_by_side_final(datasets):
    dataset_names = list(datasets.keys())
    fig = plt.figure(figsize=(20, 10))
    outer_spec = gridspec.GridSpec(nrows=1, ncols=3, wspace=0.6)

    for i, dataset_name in enumerate(dataset_names):
        df = datasets[dataset_name]
        data = df.select_dtypes(include=[np.number]).dropna()
        X_2D = SKPCA(n_components=2, random_state=42).fit_transform(StandardScaler().fit_transform(data))

        model_dict = build_models()
        cmap_used = COLORMAPS[dataset_name]
        heatmap_mode = HEATMAP_TYPE[dataset_name]

        x_min, x_max = X_2D[:, 0].min() - 0.5, X_2D[:, 0].max() + 0.5
        y_min, y_max = X_2D[:, 1].min() - 0.5, X_2D[:, 1].max() + 0.5
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300), np.linspace(y_min, y_max, 300))

        model_order = sorted(model_dict.keys(), key=lambda m: (MODEL_TYPES[m], m))
        grouped_models = [model_order[i:i + 2] for i in range(0, 8, 2)]

        inner_spec = gridspec.GridSpecFromSubplotSpec(
            nrows=4, ncols=3,
            width_ratios=[0.5, 4, 4],
            wspace=0.2, hspace=0.3,
            subplot_spec=outer_spec[i]
        )

        for row_idx, model_pair in enumerate(grouped_models):
            ax_label = fig.add_subplot(inner_spec[row_idx, 0])
            ax_label.axis("off")
            ax_label.text(0.9, 0.5, MODEL_TYPES[model_pair[0]], fontsize=9,
                          fontweight='bold', rotation=90, ha='right', va='center', transform=ax_label.transAxes)

            for col_idx, model_name in enumerate(model_pair):
                ax = fig.add_subplot(inner_spec[row_idx, col_idx + 1])
                model = model_dict[model_name]
                try:
                    model.fit(X_2D)
                    Z = compute_outlier_scores_2d(model, X_2D, xx, yy, heatmap_mode)
                    ax.pcolormesh(xx, yy, Z, cmap=cmap_used, shading='auto')
                    ax.scatter(X_2D[:, 0], X_2D[:, 1], c='black', s=6)
                    ax.set_title(model_name, fontsize=8)
                except Exception as e:
                    print(f"Error with {model_name} on {dataset_name}: {e}")
                    ax.set_title(f"{model_name} - Error", fontsize=8)

                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_xlim(x_min, x_max)
                ax.set_ylim(y_min, y_max)

    
        fig.text(0.14 + i * 0.33, 0.955, dataset_name, ha='center', fontsize=13, fontweight='bold')

        if dataset_name == "Obesity":
            colorbar_left = 0.33
        elif dataset_name == "TripAdvisor":
            colorbar_left = 0.65
        else:
            colorbar_left = 0.97

        cbar_ax = fig.add_axes([colorbar_left, 0.14, 0.012, 0.72])
        dummy = plt.cm.ScalarMappable(cmap=cmap_used)

       
        if heatmap_mode == "binary":
            cbar = fig.colorbar(dummy, cax=cbar_ax, ticks=[0, 1])
            cbar.ax.set_yticklabels(["Inlier", "Outlier"])
        else:
            cbar = fig.colorbar(dummy, cax=cbar_ax, ticks=[0, 1])
            cbar.ax.set_yticklabels(["Likely Inlier", "Likely Outlier"])

        cbar.ax.tick_params(labelsize=8)

    output_path = os.path.join(OUTPUT_DIR, "beforethresholdimage.png")
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"\nSaved: {output_path}")


if __name__ == "__main__":
    datasets = load_cleaned_data()
    plot_side_by_side_final(datasets)
