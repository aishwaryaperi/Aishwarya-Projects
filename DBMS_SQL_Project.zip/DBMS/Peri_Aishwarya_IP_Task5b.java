import java.io.File;
import java.io.FileWriter;
import java.sql.Connection; 
import java.sql.Statement; 
import java.util.Scanner; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
 public class Peri_Aishwarya_IP_Task5b {
	
	// Database credentials
	final static String HOSTNAME = "peri0015-sql-server.database.windows.net";
	final static String DBNAME = "cs-dsa-4513-sql-db"; 
	final static String USERNAME = "peri0015";
	final static String PASSWORD = "Gokaraju@0525";
	
	// Database connection string
	final static String URL =
	String.format("jdbc:sqlserver://%s:1433;database=%s;user=%s;password=%s;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;",
	HOSTNAME, DBNAME, USERNAME, PASSWORD);
	
	
    // User input prompt// 
    final static String PROMPT =  
    		"\nPlease select one of the options below: \n" + 
    		"1. Enter a new customer (30/day); \n" +
    		"2. Enter a new department (infrequent) ;\n" +
    		"3. Enter a new process-id and its department together with its type and information relevant to the type (infrequent) ; \n" +
    		"4. Enter a new assembly with its customer-name, assembly-details, assembly-id, "
    		+ "and date-ordered and associate it with one or more processes (40/day) ; \n" +
    		"5. Create a new account and associate it with the process, assembly, or department to which it is applicable (10/day) ; \n" +
    		"6. Enter a new job, given its job-no, assembly-id, process-id, and date the job commenced (50/day) ; \n" +
    		"7. At the completion of a job, enter the date it completed and the information relevant to the type of job (50/day) ; \n" +
    		"8. Enter a transaction-no and its sup-cost and update all the costs"
    		+ " (details) of the affected accounts by adding sup-cost to their current values of details (50/day) ; \n" +
    		"9. Retrieve the total cost incurred on an assembly-id (200/day) ; \n" +
    		"10. Retrieve the total labor time within a department for jobs completed in the department during a given date (20/day) ; \n" +
    		"11. Retrieve the processes through which a given assembly-id has passed so far"
    		+ " (in date-commenced order) and the department responsible for each process (100/day) ; \n" +
    		"12. Retrieve the customers (in name order) whose category is in a given range (100/day) ; \n" +
    		"13. Delete all cut-jobs whose job-no is in a given range (1/month) ; \n" +
    		"14. Change the color of a given paint job (1/week) ; \n" +
    		"15. Import: enter new customers from a data file until the file is empty"
    		+ " (the user must be asked to enter the input file name) ; \n" +
    		"16. Export: Retrieve the customers (in name order) whose category is in a given range "
    		+ "and output them to a data file instead of screen (the user must be asked to enter the output file name) ; \n" +
    		"17. Quit";
   
    
    public static void main(String[] args) throws SQLException { 
    	 
        System.out.println("Welcome to the application - peri!"); 
        final Scanner sc = new Scanner(System.in); // Scanner is used to collect the user input 
        String option = ""; // Initialize user option selection as nothing 
        while (!option.equals("17")) { // As user for options until option 4 is selected 
            System.out.println(PROMPT); // Print the available options 
            option = sc.next(); // Read in the user option selection 
 
            switch (option) { // Switch between different options 
                    
                case "1": // Insert customer details
                 try {
                    System.out.println("Enter customer name:");
                    sc.nextLine();
                    String customer_name = sc.nextLine(); 
 
                    System.out.println("Enter customer address:");
                    String customer_address= sc.nextLine(); 
                  
                    System.out.println("Enter category"); 
                    int category = sc.nextInt();
                    
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("EXEC proc1 @customer_name = ?, @cust_address = ?,@category = ?")) { 
                            // Populate the query template with the data collected from the user 

                            statement.setString(1, customer_name); 
                            statement.setString(2, customer_address);
                            statement.setInt(3, category); 
 
                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 
                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        } 
                    } 
            }
            catch(Exception error) {
    			//error.printStackTrace();
    			System.out.println("error in case 1");
    		}
            
                    break;
                    
                case "2": // Insert department details
                    try {
                    System.out.println("Enter department number"); 
                    int department_no = sc.nextInt(); // 
 
                    System.out.println("Enter department data:");
                    sc.nextLine(); 
                    String department_data = sc.nextLine(); 
 
                   
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement("EXEC proc2 @department_no = ?,@department_data = ?")) { 
                            // Populate the query template with the data collected from the user 
                            statement.setInt(1, department_no); 
                            statement.setString(2, department_data); 
                            
 
                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 
                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        } 
                    } 
            }
            catch(Exception error) {
    			error.printStackTrace();
    			System.out.println("error in case 2");
    		}
            
                    break;
 
                case "3": // Insert customer details
                	try {
                    System.out.println("Enter process type:");
                    sc.nextLine();
                    String process_type = sc.nextLine(); 
 
                    System.out.println("Enter process id"); 
                    int process_id = sc.nextInt(); // 
                    
                    System.out.println("Enter process data:");
                    sc.nextLine(); 
                    String process_data = sc.nextLine(); 
                    
                    System.out.println("Enter fit type:");
                    String fit_type = sc.nextLine(); 
                    
                    System.out.println("Enter paint type:");
                    String paint_type = sc.nextLine(); 
                    
                    System.out.println("Enter painting method:");
                    String painting_method = sc.nextLine();


                    System.out.println("Enter cut type:"); 
                    String cut_type = sc.nextLine(); 
                    
                    System.out.println("Enter machine type:");
                    String machine_type = sc.nextLine(); 
                    
                    System.out.println("Enter department number"); 
                    int dept_no = sc.nextInt(); // 
 

                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc3 @process_type = ?, @process_id = ?, @process_data = ?, @fit_type = ?, @paint_type = ?, @painting_method	= ?, @cutting_type =	?, @machine_type = ?, @department_no = ?;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setString(1, process_type);
                            statement.setInt(2, process_id); 
                            statement.setString(3, process_data);
                            statement.setString(4, fit_type);
                            statement.setString(5, paint_type);
                            statement.setString(6, painting_method);
                            statement.setString(7, cut_type);
                            statement.setString(8, machine_type);
                            statement.setInt(9, dept_no);
                            
                            
                            
                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        }
                    } 
                	}
                	catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 3");
            		}
                    
                    break;
 
                    
                case "4": // Insert customer details
                    try {
                    System.out.println("Enter assembly id"); 
                    int assid = sc.nextInt(); // 
 
                    System.out.println("Enter assembly date:");
                    sc.nextLine(); 
                    String assdate = sc.nextLine(); 
 
                    System.out.println("Enter assembly details:");
                    String assdetails = sc.nextLine(); 
                    
                    System.out.println("Enter the customer name:");
                    String customer_name = sc.nextLine();
                    
                    System.out.println("Enter no of process:");
                    int no_of_process = sc.nextInt();

                    System.out.println("Connecting to the database..."); 
                    // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("EXEC proc4 @assembly_id = ?, @assembly_date = ?, @assembly_details = ?, @cust_name = ?;")) { 
                            // Populate the query template with the data collected from the user 
                            statement.setInt(1, assid); 
                            statement.setString(2, assdate); 
                            statement.setString(3, assdetails);
                            statement.setString(4, customer_name);
                                                     
                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        } 
                    } 
                    
                	for(int i = 1 ; i <= no_of_process; i++) {
                    	
                		System.out.println("enter assembly id:");
                		int assid1 = sc.nextInt();
                		
                		System.out.println("enter the process id");
                		int assproid = sc.nextInt();
                		
                		try (final Connection connection1 = DriverManager.getConnection(URL)) { 
                            try(
	                            final PreparedStatement statement1 = connection1.prepareStatement("EXEC Proc4_1 @process_id = ?, @assembly_id = ?;")) { 
	                            // Populate the query template with the data collected from the user 
	                            statement1.setInt(1, assproid);
	                            statement1.setInt(2,assid1);
	                            
	                            
	                            final int rows_inserted1 = statement1.executeUpdate(); 

	                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted1));
	                            
                            }
                		}
                	}
            }
            catch(Exception error) {
    			error.printStackTrace();
    			System.out.println("error in case 4");
    		}
            
 
                    break;
                    
                case "5": // Insert customer details
                	try {
                    System.out.println("Enter account number:");
                    sc.nextLine();
                    int acc_no = sc.nextInt(); 
 
                    System.out.println("Enter account date:");
                    sc.nextLine();
                    String acc_date = sc.nextLine(); // 
                    
                    System.out.println("Enter acc associated to:");
                    String acc_associate = sc.nextLine(); 
                    
                    System.out.println("Enter details2 for process:");
                    float details2 = sc.nextFloat(); 
                    
                    System.out.println("Enter details1 for assembly");
                    float details1 = sc.nextFloat(); 
                    
                    System.out.println("Enter details3 for dept:");
                    Float details3 = sc.nextFloat();


                    System.out.println("Enter department number:"); 
                    int accdeptno = sc.nextInt(); 
                    
                    System.out.println("Enter process id:");
                    int accproid = sc.nextInt(); 
                    
                    System.out.println("Enter assembly id:"); 
                    int accassid = sc.nextInt(); // 
 

                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc5 @acc_no = ?, @acc_date = ?, @acc_associate = ?, @details_2 = ?, @details_1 = ?, @details_3 = ?, @department_no =  ?, @process_id = ?, @assembly_id = ?;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setInt(1, acc_no);
                            statement.setString(2, acc_date); 
                            statement.setString(3, acc_associate);
                            statement.setFloat(4, details2);
                            statement.setFloat(5, details1);
                            statement.setFloat(6, details3);
                            statement.setInt(7, accdeptno);
                            statement.setInt(8, accproid);
                            statement.setInt(9, accassid);
                            
                            
                            
                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        }
                    } 
            }
            catch(Exception error) {
    			error.printStackTrace();
    			System.out.println("error in case 5");
    		}
            
                    break;
                    
                case "6" :
                	try {
                	System.out.println("enter the job no");
                	sc.nextLine();
                    String job_no = sc.nextLine(); 
 
                    System.out.println("Enter job commenced date:");
                    sc.nextLine();
                    String commenced_date = sc.nextLine(); // 
                    
                    System.out.println("Enter assembly id");
                    int jassid = sc.nextInt();
                    
                    System.out.println("Enter process id");
                    int jproid = sc.nextInt();
                    
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc6 @job_no = ?, @commenced_date = ?, @assembly_id = ? , @process_id = ? ;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setString(1, job_no);
                            statement.setString(2, commenced_date); 
                            statement.setInt(3, jassid);
                            statement.setInt(4, jproid);

                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        }
                    } 
                	}
                    catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 6");
            		}
                     break;
                    
                case "7" :
                	try {
                	System.out.println("enter the job no");
                	sc.nextLine();
                    String job_no1 = sc.nextLine(); 
 
                    System.out.println("Enter job completed date:");
                    String completed_date = sc.nextLine(); // 
                    
                    System.out.println("Enter job type");
                    String job_type = sc.nextLine();
                    
                    System.out.println("Enter labor time");
                    String labor_time = sc.nextLine();
                    
                    
                    System.out.println("Enter color");
                    String color = sc.nextLine();
                    
                    System.out.println("Enter volume");
                    String volume = sc.nextLine();
                    
                    
                    System.out.println("Enter type of machine");
                    String type_of_machine = sc.nextLine();
                    
                    System.out.println("Enter amount of time:");
                    String amt_of_time = sc.nextLine();
                    
                    System.out.println("Enter the material:");
                    String material = sc.nextLine();
                    
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc7 @job_no = ?, @completed_date = ?, @job_type = ?, @labor_time = ?, @color = ?, @volume = ?, @type_of_machine_used = ?, @amount_of_time = ?, @material = ?;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setString(1, job_no1);
                            statement.setString(2, completed_date); 
                            statement.setString(3, job_type);
                        	statement.setString(4, labor_time);
                            statement.setString(5, color); 
                            statement.setString(6, volume);
                        	statement.setString(7, type_of_machine);
                            statement.setString(8, amt_of_time); 
                            statement.setString(9, material);

                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        }
                    }
            }catch(Exception error) {
    			error.printStackTrace();
    			System.out.println("error in case 7");
    		}
            
                    
                    break;
                    
                case "8" :
                	try {
                	System.out.println("enter the transaction number");
                	sc.nextLine();
                    int trans_no = sc.nextInt(); 
 
                    System.out.println("Enter supcost");
                    float supcost = sc.nextFloat(); // 
                    
                    System.out.println("Enter account number");
                    int acc_number = sc.nextInt();

                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc8 @transaction_id = ?, @sup_cost = ?, @acc_no = ?;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setInt(1, trans_no);
                            statement.setFloat(2, supcost); 
                            statement.setInt(3, acc_number);

                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        }
                    } 
                	}
                    catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 8");
            		}
                     break;
                case "9" : 
                	try {
                    System.out.println("Enter assembly id:"); 
                    int ass_id = sc.nextInt(); // 
 
                    System.out.println("Connecting to the database..."); 

                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try (  final PreparedStatement statement = connection.prepareStatement("exec proc9 @assembly_id = ?;")) { 
                        	
                        	
                        		statement.setInt(1,ass_id);
                        		
                        		ResultSet resultSet = statement.executeQuery();
                        		
                        		System.out.println("results of query 9: \n");
                        		sc.nextLine();
 
                                System.out.println("Total cost on assembly id: \n");
                                System.out.println("total cost\n"); 
 
                                // Unpack the tuples returned by the database and print them out to the user 
                                while (resultSet.next()) { 
                                    System.out.println(String.format(	"%s", 
                                       
                                        resultSet.getInt(1))); 

                                } 
                        } 
                    } 
                	}
                	catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 9");
            		}
                    break;
                    
                    
                
                     
                case "10": 
                    try {
                    System.out.println("Enter department number"); 
                    int department_no = sc.nextInt(); // 
 
                    System.out.println("Enter date:");
                    sc.nextLine(); 
                    String department_data = sc.nextLine(); 
 
                   
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement("EXEC proc10 @department_no = ?,@date = ?")) { 
                            // Populate the query template with the data collected from the user 
                            statement.setInt(1, department_no); 
                            statement.setString(2, department_data); 
                            
 
                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 
                            System.out.println(String.format("Done. %d rows inserted.", rows_inserted)); 
                        } 
                    } 
            }
            catch(Exception error) {
    			error.printStackTrace();
    			System.out.println("error in case 2");
    		}
            
                    break;
 

                case "11" : 
                	try {
                    System.out.println("Enter assembly id:"); 
                    int assid = sc.nextInt(); // 
 
                    
                    System.out.println("Connecting to the database..."); 

                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try (  final PreparedStatement statement = connection.prepareStatement("Exec proc11 @assembly_id = ?;")) { 
                        	
                        	
                        		statement.setInt(1, assid);
                        		
                        		ResultSet resultSet = statement.executeQuery();
                        		
                        		System.out.println("results of query 11: \n");
                        		sc.nextLine();
 
                                System.out.println("Contents of the customer table: \n");
                                System.out.println("Commenced date | Process_id 	| Department_no	\n"); 
 
                                // Unpack the tuples returned by the database and print them out to the user 
                                while (resultSet.next()) { 
                                    System.out.println(String.format(	"%s  	 | 	%s	   |	   %s  ", 
                                        resultSet.getString(1), 
                                        resultSet.getString(2), 
                                        resultSet.getInt(3))); 

                                } 
                        } 
                    } 
                	}
                	catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 11");
            		}
                    
 
                    break;
                                    
                    
                    
                case "12" : 
                	try {
                    System.out.println("Enter low category:"); 
                    int low_cat = sc.nextInt(); // 
 
                    System.out.println("Enter high category:");
                    int high_cat = sc.nextInt(); 
                    
                    System.out.println("Connecting to the database..."); 

                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try (  final PreparedStatement statement = connection.prepareStatement("Exec proc12 @low_cat = ?, @high_cat = ?;")) { 
                        	
                        	
                        		statement.setInt(1, low_cat);
                        		statement.setInt(2, high_cat); 
                        		
                        		ResultSet resultSet = statement.executeQuery();
                        		
                        		System.out.println("results of query 12: \n");
                        		sc.nextLine();
 
                                System.out.println("Contents of the customer table: \n");
                                System.out.println("cust_name | cust_address 		| category	\n"); 
 
                                // Unpack the tuples returned by the database and print them out to the user 
                                while (resultSet.next()) { 
                                    System.out.println(String.format(	"%s   | 	%s	   |	   %s  ", 
                                        resultSet.getString(1), 
                                        resultSet.getString(2), 
                                        resultSet.getInt(3))); 

                                } 
                        } 
                    } 
                	}
                	catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 12");
            		}
                    break;
                    
                case "13" :
                	try {
                    System.out.println("Enter low jobno:"); 
                    int low_jobno = sc.nextInt(); // 
 
                    System.out.println("Enter high jobno:");
                    int high_jobno = sc.nextInt();
                    
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc13 @low_jobno = ? ,@high_jobno = ?;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setInt(1, low_jobno);
                            statement.setInt(2, high_jobno); 


                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. rows deleted.", rows_inserted)); 
                        }
                    } 
            }catch(Exception error) {
    			error.printStackTrace();
    			System.out.println("error in case 13");
    		}
            
                    break;
                    
                    
                case "14" :
                	try {
                	System.out.println("enter the job no");
                	sc.nextLine();
                    String job_no2 = sc.nextLine(); 

                    
                    System.out.println("Enter color to be changed");
                    String color1 = sc.nextLine();
                    
                    
                    System.out.println("Connecting to the database..."); 
                 // Get a database connection and prepare a query statement 
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try ( 
                            final PreparedStatement statement = connection.prepareStatement
                            ("exec proc14 @job_no = ?,  @color = ?;"))
                            { 
                            // Populate the query template with the data collected from the user  
                        	statement.setString(1, job_no2);
                            statement.setString(2, color1); 


                            System.out.println("Dispatching the query..."); 
                            // Actually execute the populated query 
                            final int rows_inserted = statement.executeUpdate(); 

                            System.out.println(String.format("Done. %d row updated.", rows_inserted)); 
                        }
                    } 
                	}catch(Exception error) {
            			error.printStackTrace();
            			System.out.println("error in case 14");
            		}
                    
                    break;
 
                case "15":
                	try {
                		String file_name,line;
                		System.out.println("enter the file name to read");
                		file_name = sc.next();
                		
                		File file = new File(file_name);
                		
                		Scanner sc1 = new Scanner(file);
                		
                		while(sc1.hasNextLine()) {
                			line = sc1.nextLine();
                			
                			String[] parts = line.split(",");
                			
                			String cust_name = parts[0];
                			String cust_address = parts[1];
                			int insert_category = Integer.parseInt(parts[2]);
                			
                			final String query15 = "EXEC proc1 @customer_name = '"+cust_name+"', @cust_address = '"+cust_address+"' , @category = '"+insert_category+"';";
                			
                			try(final Connection connection = DriverManager.getConnection(URL)){
                				try(final PreparedStatement statement = connection.prepareStatement(query15)){
                					final int rows_inserted = statement.executeUpdate();
                					
                					System.out.println(String.format("Done. %d rows inserted.", rows_inserted));
                				}
                			}
                		}
                	}catch(Exception error) {
                			error.printStackTrace();
                			System.out.println("You got an error in import");
                		}
                	break;
                case "16": 
                	try {
                	String file_name;
                	int low_category, high_category;
                	
                	System.out.println("Enter the file name");
                	file_name = sc.next();
                	
                	System.out.println("Enter lower category number");
                	low_category = sc.nextInt();
                	
                	
                	System.out.println("Enter high category number");
                	high_category = sc.nextInt();
                	
                	FileWriter fw = new FileWriter(file_name);
                	
                	final String query16 = "EXEC proc12 @low_cat = '"+low_category+"', @high_cat = '"+high_category+"';";
                	
                    try (final Connection connection = DriverManager.getConnection(URL)) { 
                        try (  final PreparedStatement statement = connection.prepareStatement(query16)) { 
                        	
                        	final ResultSet resultset = statement.executeQuery();
                        	
                        	while(resultset.next()) {
                        		fw.write(resultset.getString(1)+"\n");
                        	}
                        	fw.close();
                        }
                        }
                	}catch(Exception error) {
                		error.printStackTrace();
                		System.out.println("You got an error in export");
                	}

                    break; 
                case "17": // Quiting 
                    System.out.println("Quiting! Good-bye!"); 
                    break; 
                default: // option not selected from 1 - 4, re-prompt the user for the correct one 
                    System.out.println(String.format( 
                        "option not selected from 1 - 17: %s\n" +  
                        "Please try again!",  
                        option)); 
                    break; 
            } 
        } 
 
        sc.close(); // Close the scanner before exiting the application 
    } 


}

