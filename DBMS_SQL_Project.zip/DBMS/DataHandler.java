package Aishwarya;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
public class DataHandler {
	private Connection conn;
	// Azure SQL connection credentials
	private String server = "peri0015-sql-server.database.windows.net";
	private String database = "cs-dsa-4513-sql-db";
	private String username = "peri0015";
	private String password = "Gokaraju@0525";
	
	// Resulting connection string
	final private String url =
	String.format("jdbc:sqlserver://%s:1433;database=%s;user=%s;password=%s;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;",
	server, database, username, password);
	
	// Initialize and save the database connection
	private void getDBConnection() throws SQLException {
		if (conn != null) {
			return;
		}
		this.conn = DriverManager.getConnection(url);
	}
	
	// Return the result of selecting everything from the movie_night table
	public ResultSet getAllCustomers() throws SQLException {
		getDBConnection();
		final String sqlQuery = "select * from customer;"; // query same as case 12
		final PreparedStatement stmt = conn.prepareStatement(sqlQuery);
		return stmt.executeQuery();
	}
	
	// Inserts a record into the movie_night table with the given attribute values
	public boolean addCustomer(
		String customer_name, String cust_address, int category) throws SQLException {
		getDBConnection(); // Prepare the database connection
		// Prepare the SQL statement
		final String sqlQuery =
		"INSERT INTO customer (customer_name, cust_address, category) " +
		"VALUES " +
		"(?, ?, ?)"; // query same as case 1
		final PreparedStatement stmt = conn.prepareStatement(sqlQuery);
		// Replace the '?' in the above statement with the given attribute values
		stmt.setString(1, customer_name);
		stmt.setString(2, cust_address);
		stmt.setInt(3, category);

		// Execute the query, if only one record is updated, then we indicate success by returning true
		return stmt.executeUpdate() == 1;
	}
	
	// Return the result of selecting everything from the movie_night table
	public ResultSet getretriveCustomers(int low_cat, int high_cat) throws SQLException {
		getDBConnection();
		System.out.println(low_cat);
		final String sqlQuery = "select * from customer where customer.category >= "+low_cat+" and category <= "+high_cat+" order by customer.customer_name;"; // query same as case 12
		Statement stmt = conn.createStatement();
		
		return stmt.executeQuery(sqlQuery);
	}
}