----- for proc1
----- Q1
drop procedure if exists proc1;
GO
CREATE PROCEDURE proc1
    @customer_name VARCHAR(200),
    @cust_address VARCHAR(200),
    @category int

AS
BEGIN
insert into customer
(
    customer_name,cust_address,category
)
VALUES(@customer_name,@cust_address,@category)
END



----- Q2
drop procedure if exists proc2;
GO
CREATE PROCEDURE proc2
    @department_no int,
    @department_data VARCHAR(200)

AS
BEGIN
insert into Department
(
    department_no,department_data
)
VALUES(@department_no,@department_data)
END


----Q3
drop procedure if exists proc3

GO
CREATE PROCEDURE proc3
    @process_type VARCHAR(200),
    @process_id int,
    @process_data VARCHAR(200),
    @fit_type VARCHAR(200) = NULL,
    @paint_type VARCHAR(200)=NULL,
    @painting_method VARCHAR(200)= NULL,
    @cutting_type VARCHAR(200) = NULL,
    @machine_type VARCHAR(200)= NULL,
    @department_no INT
AS    
BEGIN
insert into process
(
    process_id, process_data
)
VALUES(@process_id,@process_data)

insert into Supervises(
    process_id,department_no
)
VALUES(@process_id, @department_no)

IF @process_type = 'fit'

BEGIN
Insert into fit(
    process_id,fit_type
)
VALUES(@process_id,@fit_type)
END

IF @process_type = 'paint'
BEGIN
INSERT into paint(
    process_id,paint_type,painting_method
)
values (@process_id,@paint_type,@painting_method)
END

IF @process_type = 'cut'
BEGIN
insert into cut(
    process_id,cutting_type,machine_type
)
values (@process_id,@cutting_type,@machine_type)

END
END


----Q4
drop procedure if exists proc4
GO
CREATE PROCEDURE proc4
    @assembly_id int,
    @assembly_date VARCHAR(200),
    @assembly_details VARCHAR(200),
    @cust_name VARCHAR(200)

AS
BEGIN

insert into assembly(
    assembly_id,assembly_date,assembly_details
)
VALUES(@assembly_id, @assembly_date, @assembly_details)

insert into Orders(
    assembly_id,customer_name
)
values(@assembly_id, @cust_name)

END


drop procedure if exists Proc4_1
GO
CREATE PROCEDURE Proc4_1
    @process_id int,
    @assembly_id int

AS
BEGIN
insert into Contain(
    assembly_id,process_id
)
VALUES(@assembly_id,@process_id)

END

DELETE orders where assembly_id = 202;
delete assembly where assembly_id = 202;

drop PROCEDURE if EXISTS proc5

GO
CREATE PROCEDURE proc5
    @acc_no int,
    @acc_date VARCHAR(200),
    @acc_associate VARCHAR(200),
    @details_2 REAL,
    @details_1 REAL,
    @details_3 REAL,
    @department_no INT,
    @process_id int,
    @assembly_id INT

AS
BEGIN

insert into Account(
    acc_no,acc_date
)VALUES(@acc_no,CAST(@acc_date AS date))

IF @acc_associate = 'process'
BEGIN
insert into process_account(
    acc_no,details_2
)VALUES(@acc_no,@details_2)

INSERT into process_tracks(
    acc_no,process_id
)VALUES(@acc_no,@process_id)
END

IF @acc_associate = 'assembly'
BEGIN
insert into Assembly_account(
    acc_no,details_1
)VALUES(@acc_no,@details_1)
insert INTO assembly_tracks(
    acc_no,assembly_id
)VALUES(@acc_no,@assembly_id)
END


IF @acc_associate = 'department'
BEGIN
insert into Dept_account(
    acc_no,details_3
)VALUES(@acc_no,@details_3)

insert into dept_tracks(
    acc_no, department_no
)VALUES(@acc_no,@department_no)
END
END

delete Assembly_account where acc_no = 2222;
delete Account where acc_no = 2222


---Q6

drop procedure if exists proc6

GO
CREATE PROCEDURE proc6
    @job_no int,
    @commenced_date VARCHAR(200),
    @assembly_id int,
    @process_id INT

AS
BEGIN

insert INTO Job(
    job_no,commenced_date
)values(@job_no,@commenced_date)

insert into Assigns(
    job_no,assembly_id,process_id
)VALUES(@job_no,@assembly_id,@process_id)

END

---Q7

drop PROCEDURE IF EXISTS proc7

GO
CREATE PROCEDURE proc7
    @job_no int,
    @completed_date VARCHAR(200),
    @job_type VARCHAR(200),
    @labor_time VARCHAR(200),
    @color VARCHAR(200),
    @volume int,
    @type_of_machine_used VARCHAR(200),
    @amount_of_time VARCHAR(200),
    @material VARCHAR(200)

AS
BEGIN

update Job SET completed_date = @completed_date WHERE job_no = @job_no

if @job_type = 'fit job'
BEGIN
insert into Fit_job(
    job_no,labor_time
)VALUES(@job_no,cast(@labor_time as time))
END

if @job_type = 'paint job'
BEGIN
insert into paint_job(
    color,volume,labor_time,job_no
)
VALUES (@color,@volume,cast(@labor_time as time),@job_no)
END

if @job_type = 'cut job'
BEGIN
INSERT INTO Cut_job(
    type_of_machine_used, amount_of_time,material,labor_time,job_no
)
VALUES(@type_of_machine_used,cast(@amount_of_time as time),@material,cast(@labor_time as time),@job_no)

END
END


---Q8

drop PROCEDURE if EXISTS proc8

GO
CREATE PROCEDURE proc8

    @transaction_id INT,
    @sup_cost real,
    @acc_no INT
AS
BEGIN

insert into Transactions(
    transaction_id,sup_cost
)VALUES(@transaction_id,@sup_cost)


update Assembly_account
set details_1 = details_1 + @sup_cost
WHERE acc_no = @acc_no

update process_account
set details_2 = details_2 + @sup_cost
WHERE acc_no = @acc_no

update Dept_account
set details_3 = details_3 + @sup_cost
WHERE acc_no = @acc_no
END




---Q9

drop PROCEDURE if exists proc9

GO
create PROCEDURE proc9
    @assembly_id int
AS
BEGIN
    SELECT [details_1]
    FROM Assembly_account Aa
    INNER JOIN assembly_tracks Atr ON Atr.acc_no = Aa.acc_no
    WHERE assembly_id = @assembly_id
end;


exec proc9 @assembly_id = 203;

select * from assembly_tracks;

-- --- Q10
-- drop PROCEDURE if exists proc10

-- GO
-- create PROCEDURE proc10
--     @department_no INT,
--     @date DATE
-- AS
-- BEGIN
--     SELECT sum(labor_time) FROM Job J
--     INNER JOIN Assigns A on A.job_no = J.job_no
--     INNER JOIN Supervises S on S.process_id = A.process_id
--     INNER JOIN Department D ON D.department_no = S.department_no
--     INNER JOIN (
--         (SELECT job_no, labor_time FROM Fit_job) UNION (SELECT job_no, labor_time FROM Cut_job) UNION (SELECT job_no, labor_time FROM paint_job)
--     ) AS UN ON UN.job_no = J.job_no
--     WHERE D.department_no = @department_no AND J.completed_date
-- END;

-- exec proc10 



----Q11

drop PROCEDURE if exists proc11

GO
Create PROCEDURE proc11
    @assembly_id int

AS
BEGIN

select Job.commenced_date,Assigns.process_id, Supervises.department_no
from Job,Assigns,Supervises
where Assigns.assembly_id = @assembly_id and Assigns.process_id = Supervises.process_id and Assigns.job_no = Job.job_no order by Job.commenced_date; 

END

select * from Contain
select * from Supervises
select * from Assigns
----Q12

drop PROCEDURE if exists proc12;

Go
CREATE PROCEDURE proc12
    @low_cat INT,
    @high_cat INT

AS
BEGIN

select * from customer 
where category >= @low_cat AND category <= @high_cat
order by customer_name; 

END

exec proc12 @low_cat = 3, @high_cat = 4;

----Q13

drop PROCEDURE if exists proc13

GO
CREATE PROCEDURE proc13
    @low_jobno int,
    @high_jobno int

AS
BEGIN
DELETE From Cut_job where job_no between @low_jobno and @high_jobno;

END

exec proc13 @low_jobno = 1 ,@high_jobno = 4;


select * from Job
select * from Cut_job

----Q14
drop PROCEDURE if exists proc14
GO
create PROCEDURE proc14
    @color VARCHAR(200),
    @job_no VARCHAR(200)

AS
BEGIN
UPDATE paint_job set color = @color where job_no = @job_no;

END

exec proc14 @color = 'grey', @job_no ='job5';

select * from paint_job;