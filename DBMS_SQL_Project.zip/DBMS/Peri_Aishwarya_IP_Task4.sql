DROP TABLE assembly_update;
DROP TABLE process_update;
DROP TABLE Dept_update;
DROP TABLE Records;


DROP TABLE Transactions;
DROP TABLE Cut_job;
DROP TABLE Fit_job;
DROP TABLE paint_job;
DROP TABLE Assigns;
DROP TABLE Job;
DROP TABLE dept_tracks;
DROP TABLE Dept_account;
DROP TABLE assembly_tracks;
DROP TABLE Assembly_account;
DROP TABLE process_tracks;
DROP TABLE process_account;
DROP TABLE Account;
DROP TABLE Contain;
DROP TABLE Orders;
DROP TABLE assembly;
DROP TABLE cut;
DROP TABLE paint;
DROP TABLE fit;
DROP TABLE Supervises;
DROP TABLE process;
DROP TABLE Department;
DROP TABLE customer;



----1
----Creating customer table    
create table customer(
    customer_name VARCHAR(200),
    cust_address VARCHAR (200) not null,
    category int not null,
    CONSTRAINT category_ck CHECK (category BETWEEN 1 and 10),
    PRIMARY KEY (customer_name)

)

----2
----Creating Department table
create table Department(
    department_no INT,
    department_data VARCHAR (200) not null,
    PRIMARY KEY(department_no)
)


----3
----Creating process table
create table process(
    process_id INT,
    process_data VARCHAR(200) not null,
    PRIMARY KEY (process_id)
)

----4
----Creating Supervises table
create table Supervises(
    process_id INT,
    department_no INT not null,
    PRIMARY KEY(process_id),
    FOREIGN KEY (process_id) REFERENCES process(process_id), 
    FOREIGN KEY (department_no) REFERENCES Department(department_no), 
)


----5
----Creating fit table
create table fit(
    process_id INT,
    fit_type VARCHAR(200),
    PRIMARY KEY (process_id),
    FOREIGN KEY (process_id) REFERENCES process(process_id)

)

----6
----Creating paint table
create table paint(
    process_id INT,
    paint_type VARCHAR(200) not null,
    painting_method VARCHAR(60) not null,
    PRIMARY KEY (process_id),
    FOREIGN KEY (process_id) REFERENCES process(process_id)
)

----7
----Creating cut table
create table  cut(
    process_id INT,
    cutting_type VARCHAR(200) not null,
    machine_type VARCHAR(200) not null,
    PRIMARY KEY (process_id),
    FOREIGN KEY (process_id) REFERENCES process(process_id)
)

----8
----Creating assembly table  
create table assembly(
    assembly_id INT,
    assembly_date VARCHAR(200),
    assembly_details VARCHAR(200) not null,
    PRIMARY KEY (assembly_id)
)

---- 9
---- Creating Order table
create table Orders(
    assembly_id INT,
    customer_name VARCHAR(200) not null,
    PRIMARY KEY(assembly_id),
    FOREIGN KEY (assembly_id) REFERENCES assembly(assembly_id), 
    FOREIGN KEY (customer_name) REFERENCES Customer(customer_name)
)

----10
----Creating Contains table
create table Contain(
    assembly_id INT,
    process_id INT,
    PRIMARY KEY(assembly_id, process_id),
    FOREIGN KEY (assembly_id) REFERENCES assembly(assembly_id), 
    FOREIGN KEY (process_id) REFERENCES Process(process_id)
)

----11
----Creating Account table
Create table Account(
    acc_no INT,
    acc_date date not null,
    PRIMARY KEY(acc_no)
)

----12
----Creating Process account table
Create table process_account(
    acc_no INT,
    details_2 real,
    PRIMARY KEY(acc_no)
)


----13
----Creating process tracks table
create table process_tracks(
    acc_no INT not null,
    process_id INT,
    PRIMARY KEY (process_id),
    FOREIGN KEY (acc_no) REFERENCES Account(acc_no),
    FOREIGN KEY (process_id) REFERENCES Process(process_id), 
)


----14
----Creating Assembly account table
Create table Assembly_account(
    acc_no INT,
    details_1 real,
    PRIMARY KEY(acc_no)
)


----15
----Creating assembly tracks table
create table assembly_tracks(
    acc_no INT not null,
    assembly_id INT,
    PRIMARY KEY (assembly_id),
    FOREIGN KEY (acc_no) REFERENCES Account(acc_no),
    FOREIGN KEY (assembly_id) REFERENCES assembly(assembly_id), 
)



----16
----Creating Dept account table
Create table Dept_account(
    acc_no INT,
    details_3 real,
    PRIMARY KEY(acc_no)
)


----17
----Creating dept tracks table
create table dept_tracks(
    acc_no INT not null,
    department_no int,
    PRIMARY KEY (department_no),
    FOREIGN KEY (acc_no) REFERENCES Account(acc_no),
    FOREIGN KEY (department_no) REFERENCES Department(department_no), 
)


----18
----Creating Job table
Create table Job(
    job_no int,
    commenced_date date,
    completed_date date,
    PRIMARY KEY (job_no) 
)

----19
----Creating Assigns table
create table Assigns(
    job_no int,
    assembly_id INT not null,
    process_id INT not null,
    PRIMARY KEY (job_no),
    FOREIGN KEY (job_no) REFERENCES Job(job_no), 
    FOREIGN KEY (assembly_id) REFERENCES assembly(assembly_id), 
    FOREIGN KEY (process_id) REFERENCES process(process_id), 
)



----20
----Creating paint job table
create table paint_job(
    job_no int,
    color VARCHAR(200) not null,
    Volume FLOAT not null,
    labor_time time not null,
    PRIMARY KEY (job_no),
    FOREIGN KEY (job_no) REFERENCES Job(job_no)
)

----21
----Creating fit job table
create table Fit_job(
    job_no int,
    labor_time time not null,
    PRIMARY KEY (job_no),
    FOREIGN KEY (job_no) REFERENCES Job(job_no)
)

---- 22
---- Creating cut job table
create table Cut_job(
    job_no int,
    type_of_machine_used VARCHAR(200) not null,
    amount_of_time time not null,
    material VARCHAR(200) not null,
    labor_time time not null,
    PRIMARY KEY (job_no),
    FOREIGN KEY (job_no) REFERENCES Job(job_no) on delete cascade
)


-------------------

---- 23
---- Creating Transaction table
create table Transactions(
    transaction_id int,
    sup_cost REAL not null,
    PRIMARY KEY(transaction_id)
)

create index cat on customer(category);
create index date on Job(commenced_date);

-- ----24
-- ----Creating Records table
-- create table Records(
--     job_no int,
--     transaction_id INT not null,
--     PRIMARY KEY (job_no),
--     FOREIGN KEY (job_no) REFERENCES job(job_no),
--     FOREIGN KEY (transaction_id) REFERENCES Transactions(transaction_id), 

-- )

-- ----25
-- ----Creating Dept_update table
-- create table Dept_update(
--     acc_no INT not null,
--     transaction_id INT,
--     PRIMARY KEY (transaction_id),
--     FOREIGN KEY (acc_no) REFERENCES Account(acc_no),
--     FOREIGN KEY (transaction_id) REFERENCES Transactions(transaction_id), 
-- )

-- ----26
-- ----Creating  process update table
-- create table process_update(
--     acc_no INT not null,
--     transaction_id INT,
--     PRIMARY KEY (transaction_id),
--     FOREIGN KEY (acc_no) REFERENCES Account(acc_no),
--     FOREIGN KEY (transaction_id) REFERENCES Transactions(transaction_id),
-- )

-- ----27
-- ----Creating assembly update table
-- create table assembly_update(
--     acc_no INT not null,
--     transaction_id INT,
--     PRIMARY KEY (transaction_id),
--     FOREIGN KEY (acc_no) REFERENCES Account(acc_no),
--     FOREIGN KEY (transaction_id) REFERENCES Transactions(transaction_id),
-- )



